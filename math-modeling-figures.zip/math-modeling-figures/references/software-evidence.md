# 原作者软件：证据与边界

仅靠成图外观通常不能唯一识别软件。下表列可追溯的原文或代码证据，不是196篇的软件使用率统计。未明确声明的软件保留未知；PDF的Word/LaTeX元数据只能说明排版来源。

|软件|证据位置|能确认什么|级别|
|---|---|---|---|
|LucidChart|P015（2021，C-2107870），PDF第4页；P015（2021，C-2107870），PDF第11页；P015（2021，C-2107870），PDF第18页|图注明确写明制作工具；对应模型活动图、CNN过程和部门视图。|图级确认|
|Matplotlib|P015（2021，C-2107870），PDF第14页；P015（2021，C-2107870），PDF第21页|箱线图图注明确声明。|图级确认|
|Seaborn|P015（2021，C-2107870），PDF第20页|混淆矩阵图注明确声明。|图级确认|
|Tableau|P016（2021，C-2109298），PDF第6页|正文说明文中地图使用其内置函数绘制。|论文地图级确认|
|Folium|P007（2021，B-2102199），PDF第25页|附录有导入及Circle、Marker、Polygon调用。HeatMap导入本身不足以确认每幅热图。|代码证据，限定调用范围|
|MATLAB|P087（2023，2316994【公众号：竞赛资料网】整理），PDF第25页；P127（2024，2425792），PDF第11页|P087有plot调用和颜色参数；P127图7标题和正文明确轨迹在MATLAB中模拟展示。|代码/图级确认|
|MATLAB、Python、Lingo|P091（2023，2315379【公众号：竞赛资料网】整理），PDF第25页|附录把图形生成和计算工具合列；Office 2019另列为论文写作工具。不能把Lingo直接归为每幅图的绘图软件。|论文工具清单，单图不能拆分|
|Matlab、Python、Sufer、Tableau、PowerPoint、Origin|P075（2022，2223495），PDF第25页|工具清单如此拼写；Sufer可能为拼写问题，未替作者确认成Surfer。|工具清单，单图不能归属|
|Origin|P136（2024，2410482），PDF第19页|正文明确把数据导入Origin获得接下来的两幅相关分析图（图10、11）。|图级确认|
|Seaborn、Matplotlib|P130（2024，2401919），PDF第25页|附录包含sns.lineplot、plt.title、plt.show及ACF/PACF绘图调用。|代码证据|
|Matplotlib、Seaborn|P179（2025，2516695），PDF第26页|AI使用报告描述用二者生成初始图，再人工改善清晰度。属于作者工作流陈述。|作者声明，非独立运行验证|
|ArcGIS|P185（2025，2507692），PDF第6页；P185（2025，2507692），PDF第7页|正文说明经ArcGIS处理获得交通网络，紧接对应图3。|图级确认|
|Stella|P190（2025，2515136），PDF第7页|图3图注明确写Based on Stella；其库存、流和转换器符号也可见。原文称Petri网，图形可归系统动力学机制图。|图级确认|
|R、ggplot2|P196（2025，2521039），PDF第6页|正文数据处理与可视化工作流列出dplyr、countrycode和ggplot2。|论文工作流声明|

## 不能当作原作者作图证据的线索

P177 PDF第26页询问AI如何用Python画散点，P194 PDF第32–33页AI建议若干绘图库，只说明获得过建议，不能证明作者最终使用。参考文献引用ArcGIS页面也不等于作者用ArcGIS绘图。正文普通单词origin不是Origin软件证据。Python或MATLAB用于计算，也不自动说明全文每幅图均由它生成。

## 复现工具建议（与原作者归属分开）

一般定量图和复合版式可用Matplotlib；统计分布、矩阵和联合图可用Seaborn。其官方示例分别展示相关图形与布局能力：[Matplotlib gallery](https://matplotlib.org/stable/gallery/index.html)、[Seaborn gallery](https://seaborn.pydata.org/examples/index.html)。

桑基图可按source、target、value结构交给Plotly：[官方Sankey说明](https://plotly.com/python/sankey-diagram/)。SHAP蜂群应使用真实解释值与特征值：[SHAP官方蜂群说明](https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/beeswarm.html)。

每类末尾的其他工具是按图形需求给出的复现候选，不代表对应论文作者使用过，也不是要求更换现有工作流。版本、可用性与导出依赖在实际作图环境中再确认。
